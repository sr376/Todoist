# Mini-Project_Todoist

Todoist - Using Python(Tkinter)
